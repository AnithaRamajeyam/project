package com.serv.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.serv.beans.BidProduct;
import com.serv.util.DBConstants;
import com.serv.util.DBUtil;


public class BidDaoImpl implements BidDao{
		@Override
		public boolean Update(BidProduct bp) {
			Connection con=null;
			PreparedStatement pst=null;
			boolean b=false;
			ResultSet rs=null;
			try {
				con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
				SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
				String date=sf.format(new Date());
				pst=con.prepareStatement("select bidding_price from bidding");
				/*pst=con.prepareStatement("insert into bid  (bid,bidding_price,rdate) values(?,?,?) where ()");
				pst.setString(1, bp.getBidId());
				pst.setInt(2, bp.getBidPrice() );
				pst.setString(3, date);*/
				rs=pst.executeQuery();
				while(rs.next()){
					int bp1=rs.getInt("bidding_price"); 	//database
					if(bp.getBidPrice()> bp1)
					{
						System.out.println("helo");
						pst=con.prepareStatement("insert into bidding(bid,bidding_price,rdate) values(?,?,?)");
						pst.setString(1, bp.getBidId());
						pst.setInt(2, bp.getBidPrice() );
						pst.setString(3, date); 
						pst.executeUpdate();
						b=true;
					}
					else
					{
						b=false;
					}
				}
				con.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return b;
		}

		

		@Override
		public List<BidProduct> getBidDetails() {
			Connection con=null;
			Statement st=null;
			ResultSet rs=null;
			List<BidProduct> bps=new ArrayList<BidProduct>();
			try {
				con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
				st=con.createStatement();
				rs=st.executeQuery("select * from bidding");
				while(rs.next())
				{
					bps.add(new BidProduct( rs.getString(1),rs.getInt(2), rs.getString(3)));
					System.out.println(rs.getString(1));
				}
			
				rs.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		return bps;
		}
}
