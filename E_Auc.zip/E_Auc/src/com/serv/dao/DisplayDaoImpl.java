package com.serv.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.serv.beans.Display;
import com.serv.util.DBConstants;
import com.serv.util.DBUtil;

public class DisplayDaoImpl implements DisplayDao{

	@Override
	public List<Display> getProductDetails(Display sp) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		List<Display> disp=new ArrayList<Display>();
		try {
			
			conn = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME,DBConstants.PWD);
			pst = conn.prepareStatement("select * from put_for_sales where Product_id=?");
			pst.setInt(1, sp.getPid());
			rs= pst.executeQuery();
			
			while(rs.next())
			{
		
				disp.add(new Display(rs.getInt(7),rs.getString(3),rs.getString(5)));
			}
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return disp;
  }
}
