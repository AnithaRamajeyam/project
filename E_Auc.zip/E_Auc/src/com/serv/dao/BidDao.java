package com.serv.dao;

import java.util.List;

import com.serv.beans.BidProduct;

public interface BidDao {

	public boolean Update(BidProduct bp); 
	 List<BidProduct> getBidDetails();
}
