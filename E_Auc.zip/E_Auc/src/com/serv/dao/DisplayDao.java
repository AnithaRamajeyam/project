package com.serv.dao;

import java.util.List;

import com.serv.beans.Display;

public interface DisplayDao {
	
	public List<Display> getProductDetails(Display sp);
}
