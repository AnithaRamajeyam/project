package com.serv.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.serv.beans.BidProduct;
import com.serv.service.BidService;
import com.serv.service.BidServiceImpl;

@WebServlet("/BidServlet")
	public class BidServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
	   
		BidService service=new BidServiceImpl();
		List<BidProduct> bps=new ArrayList<BidProduct>();
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException {
			response.setContentType("text/html");
			int bidPrice=Integer.parseInt(request.getParameter("bidPrice")) ;
			HttpSession ss = request.getSession(); 
			String bidId = (String) ss.getAttribute("username");
			String date=request.getParameter("date") ;
			BidProduct bp= new BidProduct();
			bp.setBidPrice(bidPrice); 
			bp.setBidId(bidId);
			bp.setDate(date);
			
			if(service.Update(bp))
			{
				bps=service.getBidDetails();
				request.setAttribute("bidtable",bps);
				RequestDispatcher r1= request.getRequestDispatcher("display.jsp");
				r1.forward(request, response);
			}
			else
			{
				request.setAttribute("errormsg","invalid");
				RequestDispatcher r1= request.getRequestDispatcher("display.jsp");
				r1.forward(request, response);
			}
			
		}
}
