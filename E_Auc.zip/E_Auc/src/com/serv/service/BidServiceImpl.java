package com.serv.service;

import java.util.List;

import com.serv.beans.BidProduct;
import com.serv.dao.BidDao;
import com.serv.dao.BidDaoImpl;

public class BidServiceImpl implements BidService {

	BidDao dao= new BidDaoImpl();
	public boolean Update(BidProduct bp) {
		
		boolean res=dao.Update(bp);
		return res;
	}
	@Override
	public List<BidProduct> getBidDetails() {
		List<BidProduct> bps=dao.getBidDetails();
		return bps;
	}
}
