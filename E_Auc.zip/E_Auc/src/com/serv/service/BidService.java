package com.serv.service;

import java.util.List;

import com.serv.beans.BidProduct;

public interface BidService {
	
	public boolean Update(BidProduct bp);
	List<BidProduct> getBidDetails();  

}
