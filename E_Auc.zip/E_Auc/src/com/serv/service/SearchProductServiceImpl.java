package com.serv.service;

import java.util.List;

import com.serv.beans.SearchProduct;
import com.serv.dao.SearchProductDao;
import com.serv.dao.SearchProductDaoImpl;

public class SearchProductServiceImpl implements SearchProductService {
	
	SearchProductDao dao = new SearchProductDaoImpl();
	public List<SearchProduct> getProductInfo(SearchProduct sp)
	{
		List<SearchProduct> search=dao.getProductInfo(sp);
		
		return search;
	}

}
