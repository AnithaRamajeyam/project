package com.serv.service;

import java.util.List;

import com.serv.beans.Display;
import com.serv.dao.DisplayDao;
import com.serv.dao.DisplayDaoImpl;

public class DispalyServiceImpl implements DisplayService{
	DisplayDao dao = new DisplayDaoImpl();

	public List<Display> getProductDetails(Display sp) {
		List<Display> disp=dao.getProductDetails(sp);
		
		return disp;
	}
}
