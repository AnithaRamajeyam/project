package com.serv.service;

import java.util.List;

import com.serv.beans.Display;

public interface DisplayService {

	public List<Display> getProductDetails(Display sp);
}
