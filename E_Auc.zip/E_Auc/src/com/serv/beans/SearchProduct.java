package com.serv.beans;

import java.time.Period;

public class SearchProduct {

		String category;
		int pid;
		String Product_name;
		String Short_desc;
		Period remaining_days;
		int lastPrice;
		public SearchProduct(String category) {
			super();
			this.category = category;
		}
		
		public SearchProduct(int pid, String product_name, String short_desc,
				Period remaining_days, int lastPrice) {
			super();
			this.pid = pid;
			Product_name = product_name;
			Short_desc = short_desc;
			this.remaining_days = remaining_days;
			this.lastPrice = lastPrice;
		}

		public int getLastPrice() {
			return lastPrice;
		}

		public void setLastPrice(int lastPrice) {
			this.lastPrice = lastPrice;
		}

		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public int getPid() {
			return pid;
		}
		public void setPid(int pid) {
			this.pid = pid;
		}
		public String getProduct_name() {
			return Product_name;
		}
		public void setProduct_name(String product_name) {
			Product_name = product_name;
		}
		public String getShort_desc() {
			return Short_desc;
		}
		public void setShort_desc(String short_desc) {
			Short_desc = short_desc;
		}
		public Period getRemaining_days() {
			return remaining_days;
		}
		public void setRemaining_days(Period remaining_days) {
			this.remaining_days = remaining_days;
		}
		
}
