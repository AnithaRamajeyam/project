package com.serv.beans;

public class BidProduct {

	int bidPrice;
	String bidId;
	String date;
	int pid;
	
	public BidProduct(int bidPrice, String bidId, String date, int pid) {
		super();
		this.bidPrice = bidPrice;
		this.bidId = bidId;
		this.date = date;
		this.pid = pid;
	}
	public BidProduct() {
		
	}
	public int getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(int bidPrice) {
		this.bidPrice = bidPrice;
	}
	public String getBidId() {
		return bidId;
	}
	public void setBidId(String bidId) {
		this.bidId = bidId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}

}
