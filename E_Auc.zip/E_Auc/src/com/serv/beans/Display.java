package com.serv.beans;



public class Display {
	
		int pid;
		int start_price;
		String pname;
		String detailDesc;		
		
		public Display(int pid) {
			super();
			this.pid = pid;
		}
		public int getPid() {
			return pid;
		}
		public String getDetailDesc() {
			return detailDesc;
		}
		public void setDetailDesc(String detailDesc) {
			this.detailDesc = detailDesc;
		}
		public void setPid(int pid) {
			this.pid = pid;
		}


		public String getPname() {
			return pname;
		}


		public void setPname(String pname) {
			this.pname = pname;
		}


		public int getStart_price() {
			return start_price;
		}


		public void setStart_price(int  start_price) {
			this.start_price = start_price;
		}
		public Display(int start_price, String pname, String detailDesc) {
			super();
			this.start_price = start_price;
			this.pname = pname;
			this.detailDesc = detailDesc;
		}
		
}
